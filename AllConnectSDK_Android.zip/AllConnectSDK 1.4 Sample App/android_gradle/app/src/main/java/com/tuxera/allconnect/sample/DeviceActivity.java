package com.tuxera.allconnect.sample;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import com.tuxera.allconnect.AllConnectException;
import com.tuxera.allconnect.AllConnectRuntimeException;
import com.tuxera.allconnect.devicemanager.DeviceInfo;
import com.tuxera.allconnect.devicemanager.DeviceManager;
import com.tuxera.allconnect.devicemanager.listeners.DeviceConnectionListener;
import com.tuxera.allconnect.devicemanager.listeners.DeviceDiscoveryListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Used to discover and select devices
 */
public class DeviceActivity extends ListActivity {

    private final String TAG = this.getClass().getSimpleName();

    private List<DeviceInfo> mDiscoveredDevices = new ArrayList<>();
    private DeviceAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discovery);

        mAdapter = new DeviceAdapter(mDiscoveredDevices);
        setListAdapter(mAdapter);
        try {
            //Check if device manager is initialized
            DeviceManager.getInstance();
        } catch (AllConnectRuntimeException e) {
            //Device manager is not yet initialized. Initializing:
            new DeviceManager.Builder(this)
                    .deviceListeners(
                            new DeviceDiscoveryListener() {
                                @Override
                                public void onDeviceDiscovered(final DeviceInfo deviceInfo) {
                                    Log.i(TAG, "Device discovered\n" +
                                            "Device name: " + deviceInfo.getDeviceName() + "\n" +
                                            "Device type: " + deviceInfo.getDeviceType());
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            mDiscoveredDevices.add(deviceInfo);
                                            mAdapter.notifyDataSetChanged();
                                        }
                                    });

                                }

                                @Override
                                public void onDeviceUpdated(DeviceInfo deviceInfo) {

                                }

                                @Override
                                public void onDeviceRemoved(final DeviceInfo deviceInfo) {
                                    Log.i(TAG, "Device removed\n" +
                                            "Device name: " + deviceInfo.getDeviceName() + "\n" +
                                            "Device type: " + deviceInfo.getDeviceType());
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            mDiscoveredDevices.remove(deviceInfo);
                                            mAdapter.notifyDataSetChanged();
                                        }
                                    });
                                }
                            },
                            new DeviceConnectionListener() {
                                @Override
                                public void onDeviceConnected(DeviceInfo deviceInfo) {
                                    Log.i(TAG, "Device connected\n" +
                                            "Device name: " + deviceInfo.getDeviceName() + "\n" +
                                            "Device type: " + deviceInfo.getDeviceType());
                                }

                                @Override
                                public void onDeviceDisconnected(DeviceInfo deviceInfo, int i) {
                                    Log.i(TAG, "Device disconnected\n" +
                                            "Device name: " + deviceInfo.getDeviceName() + "\n" +
                                            "Device type: " + deviceInfo.getDeviceType());
                                }

                                @Override
                                public void onDeviceConnectionError(DeviceInfo deviceInfo, AllConnectException exception) {

                                }
                            })
                    .build();
        }
        Button button = (Button) findViewById(R.id.discover_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    //Starting to discover devices
                    DeviceManager.getInstance().stopDiscovery();
                    mDiscoveredDevices.clear();
                    mAdapter.notifyDataSetChanged();
                    DeviceManager.getInstance().startDiscovery();
                } catch (AllConnectException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            DeviceManager.destroyInstance();
        } catch (AllConnectException e) {
            Log.e(TAG, "Error occured when destroying DeviceManager", e);
        }
    }

    @Override
    public void onListItemClick(ListView list, View view, int position, long id) {
        DeviceInfo device = mDiscoveredDevices.get(position);
        try {
            //Connect to device when it is clicked.
            DeviceManager.getInstance().disconnectAllDevices();
            DeviceManager.getInstance().connectDevice(device);

            //Stopping discovery after device have been selected
            DeviceManager.getInstance().stopDiscovery();
        } catch (AllConnectException e) {
            e.printStackTrace();
        }
        Intent intent = new Intent(this, MediaActivity.class);
        startActivity(intent);
    }
}
