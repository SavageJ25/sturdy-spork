package com.tuxera.allconnect.sample;

import android.app.ListActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ListView;
import android.widget.MediaController;

import com.tuxera.allconnect.AllConnectException;
import com.tuxera.allconnect.contentmanager.ContentManager;
import com.tuxera.allconnect.contentmanager.MediaType;
import com.tuxera.allconnect.contentmanager.containers.MediaInfo;
import com.tuxera.allconnect.contentmanager.listeners.MediaListener;
import com.tuxera.allconnect.streammanager.MediaStatusReport;
import com.tuxera.allconnect.streammanager.PlaybackStatus;
import com.tuxera.allconnect.streammanager.StreamController;
import com.tuxera.allconnect.streammanager.StreamManager;
import com.tuxera.allconnect.streammanager.exceptions.PlaybackError;
import com.tuxera.allconnect.streammanager.listeners.PlaybackListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Activity for displaying media files and streaming them
 */
public class MediaActivity extends ListActivity implements PlaybackListener {

    private final String TAG = this.getClass().getSimpleName();

    private List<MediaInfo> mMediaList = new ArrayList<>();
    private MediaAdapter mAdapter;
    private MediaController mMediaControls;
    private StreamController mStreamController;
    private MediaStatusReport mStatusReport;

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (mMediaControls != null && mStreamController != null) {
            mMediaControls.show();
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media);

        ContentManager.createInstance(getApplicationContext());

        mAdapter = new MediaAdapter(mMediaList);
        setListAdapter(mAdapter);

        //Discover all local audio media
        ContentManager.getInstance().discoverLocalMedia(new MediaListener() {
            @Override
            public void onMediaDiscovered(final MediaInfo mediaInfo) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mMediaList.add(mediaInfo);
                        mAdapter.notifyDataSetChanged();
                    }
                });
            }

            @Override
            public void onQueryFinished(int statusCode) {

            }
        }, MediaType.AUDIO, false);

        //Show controls if screen is touched and something is playing
        getListView().setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (mMediaControls != null && mStreamController != null) {
                    mMediaControls.show();
                }
                return false;
            }
        });

        //Init default android media controls without fast forward or rewind
        mMediaControls = new MediaController(this, false);
        mMediaControls.setAnchorView(getListView());
        mMediaControls.setMediaPlayer(new MediaController.MediaPlayerControl() {
            @Override
            public void start() {
                try {
                    StreamManager.getInstance().play(mStreamController);
                } catch (AllConnectException e) {
                    Log.e(TAG, "Error when trying to play", e);
                }
            }

            @Override
            public void pause() {
                try {
                    StreamManager.getInstance().pause(mStreamController);
                } catch (AllConnectException e) {
                    Log.e(TAG, "Error when trying to pause", e);
                }
            }

            @Override
            public int getDuration() {
                if (mStatusReport == null) {
                    return 0;
                }
                return (int)mStatusReport.getDuration();
            }

            @Override
            public int getCurrentPosition() {
                if (mStatusReport == null) {
                    return 0;
                }
                return (int)mStatusReport.getProgress();
            }

            @Override
            public void seekTo(int pos) {
                if (mStreamController == null) {
                    return;
                }
                try {
                    StreamManager.getInstance().seek(mStreamController, pos);
                } catch (AllConnectException e) {
                    Log.e(TAG, "Error when trying to seek", e);
                }
            }

            @Override
            public boolean isPlaying() {
                if (mStatusReport == null) {
                    return false;
                }
                return mStatusReport.getStatus() == PlaybackStatus.PLAYING ? true : false;
            }

            @Override
            public int getBufferPercentage() {
                return 0;
            }

            @Override
            public boolean canPause() {
                return true;
            }

            @Override
            public boolean canSeekBackward() {
                return false;
            }

            @Override
            public boolean canSeekForward() {
                return false;
            }

            @Override
            public int getAudioSessionId() {
                return 0;
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mStreamController != null && mStreamController.isValid()) {
            StreamManager.getInstance().destroyController(mStreamController);
        }
        StreamManager.destroyInstance();
        ContentManager.destroyInstance();
    }

    @Override
    public void onListItemClick(ListView list, View view, int position, long id) {
        if (position >= mMediaList.size()) {
            return;
        }
        try {
            //Initializes streaming of clicked media to connected device
            mStreamController = StreamManager.getInstance().initStream(mMediaList.get(position), this);
            mMediaControls.setEnabled(true);
            mMediaControls.show();
        } catch (AllConnectException e) {
            Log.e(TAG, "Exception when streaming", e);
        }
    }

    //AllConnect playback listener

    @Override
    public void onStatusUpdate(StreamController streamController, MediaStatusReport mediaStatusReport) {
        mStatusReport = mediaStatusReport;
    }

    @Override
    public void onPlaybackError(StreamController streamController, PlaybackError playbackError) {

    }

    @Override
    public void onPlaybackStarted(StreamController streamController, MediaStatusReport mediaStatusReport) {
        mStatusReport = mediaStatusReport;
    }

    @Override
    public void onPlaybackPaused(StreamController streamController, MediaStatusReport mediaStatusReport) {
        mStatusReport = mediaStatusReport;
    }

    @Override
    public void onPlaybackStopped(StreamController streamController, MediaStatusReport mediaStatusReport) {
        mStatusReport = mediaStatusReport;
    }

    @Override
    public void onPlaybackFinished(StreamController streamController, MediaStatusReport mediaStatusReport) {
        mStatusReport = mediaStatusReport;
    }

    @Override
    public void passwordRequired(StreamController streamController, PlaybackError playbackError) {

    }

    @Override
    public void onControllerInvalidated(StreamController streamController) {

    }
}
