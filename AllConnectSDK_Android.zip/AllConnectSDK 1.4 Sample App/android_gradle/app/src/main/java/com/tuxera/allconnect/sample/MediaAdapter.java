package com.tuxera.allconnect.sample;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.tuxera.allconnect.contentmanager.containers.MediaInfo;

import java.util.List;

/**
 * Created by sakari on 11/03/15.
 */
public class MediaAdapter extends BaseAdapter {

    private List<MediaInfo> mMediaList;

    public MediaAdapter(List<MediaInfo> mediaList) {
        mMediaList = mediaList;
    }

    @Override
    public int getCount() {
        return mMediaList.size();
    }

    @Override
    public Object getItem(int position) {
        if (position >= mMediaList.size()) {
            return null;
        }
        return mMediaList.get(position);
    }

    @Override
    public long getItemId(int position) {
        if (position >= mMediaList.size()) {
            return 0;
        }
        return mMediaList.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View item;
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) parent.getContext()
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            item = inflater.inflate(android.R.layout.simple_list_item_1, null);
        } else {
            item = convertView;
        }
        if (position <= mMediaList.size()) {
            TextView text = (TextView) item.findViewById(android.R.id.text1);
            text.setText(mMediaList.get(position).getTitle());
        }
        return item;
    }
}
