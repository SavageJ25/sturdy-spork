package com.tuxera.allconnect.sample;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.tuxera.allconnect.devicemanager.DeviceInfo;

import java.util.List;

/**
 * Created by sakari on 11/03/15.
 */
public class DeviceAdapter extends BaseAdapter {

    List<DeviceInfo> mDeviceList;

    public DeviceAdapter(List<DeviceInfo> deviceList)  {
        mDeviceList = deviceList;
    }

    @Override
    public int getCount() {
        return mDeviceList.size();
    }

    @Override
    public Object getItem(int position) {
        if (position >= mDeviceList.size()) {
            return null;
        }
        return mDeviceList.get(position);
    }

    @Override
    public long getItemId(int position) {
        if (position >= mDeviceList.size()) {
            return 0;
        }
        return mDeviceList.get(position).hashCode();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View item;
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) parent.getContext()
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            item = inflater.inflate(android.R.layout.simple_list_item_1, null);
        } else {
            item = convertView;
        }
        if (position <= mDeviceList.size()) {
            TextView text = (TextView) item.findViewById(android.R.id.text1);
            text.setText(mDeviceList.get(position).getDeviceName());
        }
        return item;
    }
}
